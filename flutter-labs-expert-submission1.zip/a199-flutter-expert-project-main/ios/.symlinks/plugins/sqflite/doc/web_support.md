# Web support

sqflite is not supported on the web as there is no decent platform support. 
You can check https://github.com/deakjahn/sqflite_web for an initial web support but it lacks real persistency.
