## 2.0.7

* Fixes link in README.

## 2.0.6

* Split from `path_provider` as a federated implementation.
